pathappend $HOME/.rvm/bin
source /home/pkopriv2/.rvm/scripts/rvm
