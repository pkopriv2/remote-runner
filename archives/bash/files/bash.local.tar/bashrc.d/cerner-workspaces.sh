# The root directory of all workspaces
WORKSPACE_ROOT=~/Desktop/Workspace

# A static list of the available workspaces
WORKSPACES=( 	\
	"Trunk" 	\
	"Shaffer" 	\
	"Moser" 	\
	"Lester" 	\
	"Li" 		\
	"Richards" 	\
)


# Set up the workspace aliases.  These provide shortcuts to the respective
# workspace locations
alias Workspace='cd "$WORKSPACE_ROOT"'
for workspace in "${WORKSPACES[@]}"
do
	eval "alias $workspace='cd $WORKSPACE_ROOT/$workspace'"
done

clean-dependencies() {
	find target -name '*com.cerner*' | xargs rm -r
}

test-reports() {
	find . -name 'index.html' | grep 'test-reports' | xargs google-chrome
}
