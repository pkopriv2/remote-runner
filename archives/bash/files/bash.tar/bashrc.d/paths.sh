pathappend "/usr/share/google/protobuf-2.4.1"

export JAVA_HOME="/usr/share/java/jdk1.6.0_25"
pathappend "$JAVA_HOME/bin"

export GRAILS_HOME="/usr/share/grails/grails-1.3.6"
pathappend "$GRAILS_HOME/bin"

export MAVEN_HOME="/usr/share/apache-maven/apache-maven-3.0.3"
pathappend "$MAVEN_HOME/bin"

export GROOVY_HOME="/usr/share/groovy/groovy-1.8.5"
pathappend "$GROOVY_HOME/bin"
pathappend "$GROOVY_HOME/scripts"
