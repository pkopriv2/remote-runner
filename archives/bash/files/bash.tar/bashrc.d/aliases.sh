alias clip='xclip -selection clipboard'
